let balance=5000;
console.log(typeof balance)

let balance = {message:"hello"}
console.log(typeof balance);