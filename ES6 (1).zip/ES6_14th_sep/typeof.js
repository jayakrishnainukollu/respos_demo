var num="12"
console.log(typeof num)