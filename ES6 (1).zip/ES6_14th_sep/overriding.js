class PrintClass {
    doPrint(){
        console.log("doPrint() from parent class...")
    }
}

class StringPrinter extends PrintClass
{
    doPrint()
    {
        super.doPrint();
        console.log("doPrint() from child class...")
    }
}

var obj =new StringPrinter();
obj.doPrint();