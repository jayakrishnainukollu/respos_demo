let stu1={firstName:"name1",dept:'EEE'}
let stu2={...stu1}
console.log(stu2)

let stu3={lastName:"name2"}
let stu4={...stu1,...stu3}
console.log(stu4)