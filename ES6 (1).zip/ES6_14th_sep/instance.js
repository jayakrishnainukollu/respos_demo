class person
{
    
}

var obj =new person()

var isperson = obj instanceof person;

console.log("obj is an instance of person "+ isperson)