let count =100;

for(let count=1;count<=10;count++)
{
    console.log("count value inside loop is",count)
}

console.log("count value after loop is",count);

if (count==100)
{
    let count=50;
    console.log("count inside if block",count);
}

console.log(count);