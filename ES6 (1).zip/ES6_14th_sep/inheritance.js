class shape
{
    constructor(a)
    {
        this.Area =a
    }
}

class circle extends shape
{
    disp()
    {
        console.log("Area of the circle:"+this.Area)
    }
}

var obj =new circle(224)
obj.disp()